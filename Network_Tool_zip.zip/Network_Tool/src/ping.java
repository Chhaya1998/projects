
import java.io.*;
class ping 
{

    public static void main(String[] args) throws IOException
    { 
        int c=1;
        for (int i=1; i<=17;i++) 
        {
            Thread t[]=new Thread[15];
            for(int j=0;j<15;j++)
            {
              job obj = new job(c);
              t[j] = new Thread(obj);
              t[j].start();
              c++;
            }
             for(int j=0;j<15;j++)
             {
                try 
                {
                    t[j].join();
                } 
                catch (Exception ex) 
                {
                   ex.printStackTrace();
                }
             }
           System.out.println(i+" "+"slot completed");
        }
    }
}

class job implements Runnable 
{
  int ip;
  job(int ip)
  {
  this.ip = ip;
  }
 @Override
 public void run() 
 {
   try 
   {
      Process p = Runtime.getRuntime().exec("ping " + credentials.range + ip);
      DataInputStream dis = new DataInputStream(p.getInputStream());
      int count = 0;
       while (true) 
     {
        String s = dis.readLine();
         if (s == null) 
       {
         break;
       } 
         else if (s.contains("TTL")) 
       {
         count++;
       }
     }
     if (count == 4) 
     {
         System.out.println(credentials.range + ip + " " + "System Connected");
     } 
   } 
   catch (IOException ex) 
      {
        ex.printStackTrace();
      }
    }
}
    
    

