
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.io.*;
import java.lang.management.ManagementFactory;
import java.net.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class MainServer extends javax.swing.JFrame 
{
     SystemTray tray = SystemTray.getSystemTray();
       TrayIcon trayIcon;
       
    public MainServer() 
    {
        initComponents();
        setSize(400,300);
        
        // frame center
        int width = Toolkit.getDefaultToolkit().getScreenSize().width;
        int height = Toolkit.getDefaultToolkit().getScreenSize().height;

        int x = width / 2 - (this.getWidth() / 2);
        int y = height / 2 - (this.getHeight() / 2);

        setLocation(x, y);
        //
        
        if (!SystemTray.isSupported()) 
        {
            System.out.println("SystemTray is not supported");
            return;
        }
         PopupMenu pop = new PopupMenu();

        MenuItem mi1 = new MenuItem("Open");
        MenuItem mi2 = new MenuItem("Exit");

        pop.add(mi1);
        pop.add(mi2);

        mi1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tray.remove(trayIcon);
                MainServer.this.setExtendedState(NORMAL);
                MainServer.this.setVisible(true);
            }
        });
        mi2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
           
                String r = JOptionPane.showInputDialog("Enter Password");
                
                if(r.equals("2207"))
                {
                    MainServer.this.dispose();
                    System.exit(0);
                }
                else
                {
                    JOptionPane.showMessageDialog(MainServer.this, "Incorrect password");
                }
                
            }
        });
        
        trayIcon = new TrayIcon(new ImageIcon(getClass().getResource("screen.jpeg")).getImage(), "demo", pop);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        bt = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();

        jButton1.setText("jButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });
        getContentPane().setLayout(null);

        bt.setBackground(new java.awt.Color(255, 255, 153));
        bt.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        bt.setText("Start Server");
        bt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btActionPerformed(evt);
            }
        });
        getContentPane().add(bt);
        bt.setBounds(90, 90, 190, 50);

        jPanel1.setBackground(new java.awt.Color(0, 102, 102));
        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 400, 300);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btActionPerformed
        Server obj = new Server();
        Thread t = new Thread(obj);
        t.start();

        photoServer obj1 = new photoServer();
        Thread t1 = new Thread(obj1);
        t1.start();
    }//GEN-LAST:event_btActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
       this.dispose();
        try {
            tray.add(trayIcon);
        } catch (AWTException e) {
            System.out.println("TrayIcon could not be added."); 
        }// TODO add your handling code here:
    }//GEN-LAST:event_formWindowClosing

    public static void main(String args[]) 
    {
       java.awt.EventQueue.invokeLater(new Runnable() 
        {
            public void run() 
            {
                new MainServer().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bt;
    private javax.swing.JButton jButton1;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
class Server implements Runnable 
{

        @Override
        public void run() 
        {
            try 
            {
                ServerSocket sersock = new ServerSocket(5000);
                System.out.println("Server started at port 5000");
                while (true) {
                    Socket sock = sersock.accept();
                    System.out.println("Coonection accepted by client");

                    Clienthandler obj = new Clienthandler(sock);
                    Thread t = new Thread(obj);
                    t.start();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        class Clienthandler implements Runnable {

            Socket sock;

            Clienthandler(Socket sock) {
                this.sock = sock;
            }

            @Override
            public void run() {
                try {
                    DataInputStream dis = new DataInputStream(sock.getInputStream());
                    DataOutputStream dos = new DataOutputStream(sock.getOutputStream());

                    while (true) {
                        String s = dis.readLine();
                        System.out.println(s);

                        if (s.equalsIgnoreCase("hello client")) {
                            dos.writeBytes("Hello Client\r\n");
                        } else if (s.equalsIgnoreCase("Send Configuration")) {

                            String ip = InetAddress.getLocalHost().getHostAddress() + "";
                            String name = InetAddress.getLocalHost().getHostName();
                            String os = System.getProperty("os.name");
                            String pro = Runtime.getRuntime().availableProcessors() + "";
                            long memorySize = (((com.sun.management.OperatingSystemMXBean) ManagementFactory
                                    .getOperatingSystemMXBean()).getTotalPhysicalMemorySize());

                            dos.writeBytes(ip + "\r\n");
                            dos.writeBytes(name + "\r\n");
                            dos.writeBytes(os + "\r\n");
                            dos.writeBytes(pro + "\r\n");
                            dos.writeBytes(memorySize + "\r\n");
                        } else if (s.equalsIgnoreCase("Shut Down")) {
                            Runtime runtime = Runtime.getRuntime();
                            Process proc = runtime.exec("shutdown -s -t 0");
                            System.exit(0);
                        } else if (s.equalsIgnoreCase("Restart")) {
                            Runtime runtime = Runtime.getRuntime();
                            Process proc = runtime.exec("shutdown -r -t 0");
                            System.exit(0);

                        } else if (s.equalsIgnoreCase("Logg Off")) {
                            Runtime runtime = Runtime.getRuntime();
                            Process proc = runtime.exec("shutdown -l -t 0");
                            System.exit(0);

                        } else if (s.equalsIgnoreCase("Send your Screen size")) {
                            int w = Toolkit.getDefaultToolkit().getScreenSize().width;
                            int h = Toolkit.getDefaultToolkit().getScreenSize().height;

                            dos.writeInt(w);
                            dos.writeInt(h);
                        } else if (s.equalsIgnoreCase("Mouse Moved")) {
                            int x = dis.readInt();
                            int y = dis.readInt();

                            Robot rb = new Robot();
                            rb.mouseMove(x, y);
                        }
                        else if(s.equalsIgnoreCase("Mouse Clicked"))
                        {
                            int x=dis.readInt();
                            int y=dis.readInt();
                            int button=dis.readInt();
                            Robot rb=new Robot();
                            rb.mouseMove(x,y);
                            
                            if(button==1)
                            {
                                rb.mousePress(MouseEvent.BUTTON1_MASK);
                                rb.mouseRelease(MouseEvent.BUTTON1_MASK);
                            }
                            else if(button==2)
                            {
                                rb.mousePress(MouseEvent.BUTTON2_MASK);
                                rb.mouseRelease(MouseEvent.BUTTON2_MASK);
                            }
                            else
                            {
                                
                                rb.mousePress(MouseEvent.BUTTON3_MASK);
                                rb.mouseRelease(MouseEvent.BUTTON3_MASK);
                            }
                        }
                        else if(s.equalsIgnoreCase("Mouse Released"))
                        {
                            int button=dis.readInt();
                            Robot rb=new Robot();
                            
                            if(button==1)
                            {
                                rb.mouseRelease(MouseEvent.BUTTON1_MASK);
                            }
                            else if(button==2)
                            {
                                rb.mouseRelease(MouseEvent.BUTTON2_MASK);
                            }
                            else 
                            {
                                rb.mouseRelease(MouseEvent.BUTTON3_MASK);
                            }
                        }
                        else if(s.equalsIgnoreCase("double Clicked"))
                        {
                           int x=dis.readInt();
                            int y=dis.readInt();
                            Robot rb=new Robot();
                            rb.mouseMove(x,y); 
                            
                            rb.mousePress(MouseEvent.BUTTON1_MASK);
                            rb.mouseRelease(MouseEvent.BUTTON1_MASK);
                        }
                        else if(s.equalsIgnoreCase("Mouse dragged"))
                        {
                           int x=dis.readInt();
                            int y=dis.readInt();
                            Robot rb=new Robot(); 
                            rb.mouseMove(x,y); 
                            
                            rb.mousePress(MouseEvent.BUTTON1_MASK);
                        }
                        else if(s.equalsIgnoreCase("Key pressed"))
                        {
                            int code=dis.readInt();
                            Robot rb=new Robot();
                            rb.keyPress(code);
                        }
                        else if(s.equalsIgnoreCase("Key Released"))
                        {
                            int code=dis.readInt();
                            Robot rb=new Robot();
                            rb.keyRelease(code);
                        }
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }

        }
    }

    class photoServer implements Runnable {

        @Override
        public void run() {
            try {
                ServerSocket psersock = new ServerSocket(6000);
                System.out.println("waiting for server");
                while (true) {
                    Socket psock = psersock.accept();
                    System.out.println("Coonection accepted by client");

                    photoClienthandler obj = new photoClienthandler(psock);
                    Thread t = new Thread(obj);
                    t.start();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }

        }

        class photoClienthandler implements Runnable {

            Socket psock;

            photoClienthandler(Socket psock) {
                this.psock = psock;
            }

            @Override
            public void run() {
                try {
                    DataInputStream pdis = new DataInputStream(psock.getInputStream());
                    DataOutputStream pdos = new DataOutputStream(psock.getOutputStream());
                    while (true) {
                        String s = pdis.readLine();

                        System.out.println(s);

                        // photo capturing //
                        try {
                            Thread.sleep(120);
                            Robot r = new Robot();

                            // It saves screenshot to desired path
                            String path = "pic.jpg";
                            // Used to get ScreenSize and capture image
                            Rectangle capture
                                    = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
                            BufferedImage Image = r.createScreenCapture(capture);
                            ImageIO.write(Image, "jpg", new File(path));
                            System.out.println("Screenshot saved");
                        } 
                        catch (IOException | InterruptedException ex) {
                            System.out.println(ex);
                        } catch (AWTException ex) {
                            Logger.getLogger(MainServer.class.getName()).log(Level.SEVERE, null, ex);
                        }

                        File f = new File("pic.jpg");
                        FileInputStream fis = new FileInputStream(f);

                        pdos.writeLong(f.length());
                        byte b[] = new byte[1000];
                        int count = 0;

                        while (true) 
                        {
                            int r = fis.read(b, 0, 1000);
                            count = count + r;
                            pdos.write(b, 0, r);
                            if (count == f.length()) 
                            {
                                break;
                            }

                        }
                        String msg = pdis.readLine();
                        System.out.println(msg);
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }

            }
        }
    }
    
   }

