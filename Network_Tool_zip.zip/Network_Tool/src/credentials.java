
import java.io.*;

class credentials
{
   static String range= "192.168.43.18";
}