
import java.awt.Toolkit;
import java.io.*;
import java.net.Socket;
import java.util.ArrayList;


public class ComparisonFrame2 extends javax.swing.JFrame 
{

    int width = Toolkit.getDefaultToolkit().getScreenSize().width;
        int height = Toolkit.getDefaultToolkit().getScreenSize().height;
        
        String request="";
        ArrayList<PCinfo> alSelected;
                int i;
                int x=10;
                SingleComparisonPanel sp[];
        
    public ComparisonFrame2(ArrayList<PCinfo> alSelected) 
    {
        initComponents();
        setSize(width,height);
        
        this.alSelected=alSelected;
        
        sp=new SingleComparisonPanel[alSelected.size()];
        
        job jb=new job();
        Thread th=new Thread(jb);
        th.start();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        p1 = new javax.swing.JPanel();
        p2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        p3 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        p1.setBackground(new java.awt.Color(255, 204, 255));
        p1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        p1.setLayout(null);

        p2.setBackground(new java.awt.Color(102, 255, 255));
        p2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        p2.setForeground(new java.awt.Color(51, 204, 255));
        p2.setLayout(null);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pics/download.jpg"))); // NOI18N
        jLabel1.setText("jLabel1");
        p2.add(jLabel1);
        jLabel1.setBounds(10, 10, 140, 120);

        jLabel2.setText("IP Address  :");
        p2.add(jLabel2);
        jLabel2.setBounds(10, 150, 80, 14);

        jLabel3.setText("PC Name    :");
        p2.add(jLabel3);
        jLabel3.setBounds(10, 200, 70, 14);

        jLabel4.setText("Operating System   :");
        p2.add(jLabel4);
        jLabel4.setBounds(10, 240, 110, 20);

        jLabel5.setText("No. of Processors :");
        p2.add(jLabel5);
        jLabel5.setBounds(10, 290, 100, 14);

        jLabel6.setText("RAM   :");
        p2.add(jLabel6);
        jLabel6.setBounds(10, 340, 60, 14);

        p1.add(p2);
        p2.setBounds(10, 10, 160, 440);

        p3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        p3.setLayout(null);
        p1.add(p3);
        p3.setBounds(180, 10, 700, 440);

        getContentPane().add(p1);
        p1.setBounds(0, 0, 890, 460);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ComparisonFrame2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ComparisonFrame2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ComparisonFrame2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ComparisonFrame2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
               // new ComparisonFrame2().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel p1;
    private javax.swing.JPanel p2;
    private javax.swing.JPanel p3;
    // End of variables declaration//GEN-END:variables

  class job implements Runnable
  {

        @Override
        public void run() 
        {
            for(i=0;i<alSelected.size();i++)
            {
                request="send Configuration";
                Client obj=new Client(alSelected.get(i).ip);
                Thread t=new Thread(obj);
                t.start();
                
                try
                {
                   t.join();
                }
                catch(Exception ex)
                {
                    ex.printStackTrace();
                }
            }
        }
      
  }
    
    
    
class Client implements Runnable 
{

        String ip;
        
        Client(String ip) 
        {
            this.ip = ip;
        }

        @Override
        public void run() 
        {
            try 
            {
                Socket sock = new Socket(ip, 5000);
                
                DataInputStream dis = new DataInputStream(sock.getInputStream());
                DataOutputStream dos = new DataOutputStream(sock.getOutputStream());
                
                if (request.equalsIgnoreCase("Send Configuration")) 
                {
                    dos.writeBytes("Send Configuration\r\n");
                    
                    String ip = dis.readLine();
                    String name = dis.readLine();
                    String os = dis.readLine();
                    String pro = dis.readLine();
                    String ram = dis.readLine();
                    
                    sp[i]=new SingleComparisonPanel();
                    sp[i].setBounds(x,10,180,520);
                    p3.add(sp[i]);
                    x=x+250;
                    
                    sp[i].lbip.setText(ip);
                    sp[i].lbname.setText(name);
                    sp[i].lbos.setText(os);
                    sp[i].lbpro.setText(pro);
                    sp[i].lbram.setText(Math.round(Long.parseLong(ram)/(1024.0*1024*1024))+"GB");
                }
            } 
            catch (Exception ex) 
            {
                ex.printStackTrace();
            }
        }
        
    }


}
