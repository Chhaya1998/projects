
import java.awt.AWTException;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.io.*;
import java.util.*;
import javax.swing.table.*;
import javax.swing.*;
import java.awt.event.*;
import java.net.Socket;

public class MainController extends javax.swing.JFrame {

    ArrayList<String> alip = new ArrayList<>();
    ArrayList<PCinfo> al2 = new ArrayList<>();
    mytablemodel tm;
    mytablemodel2 tm2;
    
    SystemTray tray = SystemTray.getSystemTray();
       TrayIcon trayIcon;

    public MainController() {
        initComponents();
        setSize(500, 400);
        
        // frame center
        int width = Toolkit.getDefaultToolkit().getScreenSize().width;
        int height = Toolkit.getDefaultToolkit().getScreenSize().height;

        int x = width / 2 - (this.getWidth() / 2);
        int y = height / 2 - (this.getHeight() / 2);

        setLocation(x, y);
        //
        
        tm = new mytablemodel();
        tm2 = new mytablemodel2();
        jt1.setModel(tm);
        jt2.setModel(tm2);
        
        if (!SystemTray.isSupported()) 
        {
            System.out.println("SystemTray is not supported");
            return;
        }
         PopupMenu pop = new PopupMenu();

        MenuItem mi1 = new MenuItem("Open");
        MenuItem mi2 = new MenuItem("Exit");

        pop.add(mi1);
        pop.add(mi2);

        mi1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tray.remove(trayIcon);
                MainController.this.setExtendedState(NORMAL);
                MainController.this.setVisible(true);
            }
        });
        mi2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
           
                String r = JOptionPane.showInputDialog("Enter Password");
                
                if(r.equals("2207"))
                {
                    MainController.this.dispose();
                    System.exit(0);
                }
                else
                {
                    JOptionPane.showMessageDialog(MainController.this, "Incorrect password");
                }
                
            }
        });
        
        trayIcon = new TrayIcon(new ImageIcon(getClass().getResource("screen.jpeg")).getImage(), "MainController", pop);

        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        bt = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jt1 = new javax.swing.JTable();
        lb = new javax.swing.JLabel();
        bt2 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jt2 = new javax.swing.JTable();
        bt3 = new javax.swing.JButton();
        bt4 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();

        jButton1.setText("jButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });
        getContentPane().setLayout(null);

        bt.setBackground(new java.awt.Color(255, 255, 153));
        bt.setText("Detect Network");
        bt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btActionPerformed(evt);
            }
        });
        getContentPane().add(bt);
        bt.setBounds(50, 10, 150, 40);

        jt1.setBackground(new java.awt.Color(255, 255, 153));
        jt1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jt1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(50, 100, 150, 170);
        getContentPane().add(lb);
        lb.setBounds(60, 70, 140, 20);

        bt2.setBackground(new java.awt.Color(255, 255, 153));
        bt2.setText("Filter");
        bt2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt2ActionPerformed(evt);
            }
        });
        getContentPane().add(bt2);
        bt2.setBounds(280, 10, 180, 40);

        jt2.setBackground(new java.awt.Color(255, 255, 153));
        jt2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jt2);

        getContentPane().add(jScrollPane2);
        jScrollPane2.setBounds(270, 100, 190, 170);

        bt3.setBackground(new java.awt.Color(255, 255, 153));
        bt3.setText("EXPLORE");
        bt3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt3ActionPerformed(evt);
            }
        });
        getContentPane().add(bt3);
        bt3.setBounds(270, 280, 190, 30);

        bt4.setBackground(new java.awt.Color(255, 255, 153));
        bt4.setText("COMPARE");
        bt4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt4ActionPerformed(evt);
            }
        });
        getContentPane().add(bt4);
        bt4.setBounds(270, 320, 190, 30);

        jPanel1.setBackground(new java.awt.Color(153, 0, 0));
        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 490, 400);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btActionPerformed

        Detect obj = new Detect();
        Thread t = new Thread(obj);
        t.start();

    }//GEN-LAST:event_btActionPerformed

    private void bt2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt2ActionPerformed
        for (int i = 0; i < alip.size(); i++) {
            Client obj = new Client(alip.get(i));
            Thread t = new Thread(obj);
            t.start();
        }
    }//GEN-LAST:event_bt2ActionPerformed

    private void bt3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt3ActionPerformed
        Explore obj = new Explore(al2);
        obj.setVisible(true);

    }//GEN-LAST:event_bt3ActionPerformed

    private void bt4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt4ActionPerformed
        ComparisonFrame obj=new ComparisonFrame(al2);
        obj.setVisible(true);
        
    }//GEN-LAST:event_bt4ActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
this.dispose();
        try {
            tray.add(trayIcon);
        } catch (AWTException e) {
            System.out.println("TrayIcon could not be added.");
        }        // TODO add your handling code here:
    }//GEN-LAST:event_formWindowClosing

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainController().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bt;
    private javax.swing.JButton bt2;
    private javax.swing.JButton bt3;
    private javax.swing.JButton bt4;
    private javax.swing.JButton jButton1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jt1;
    private javax.swing.JTable jt2;
    private javax.swing.JLabel lb;
    // End of variables declaration//GEN-END:variables
    class mytablemodel extends AbstractTableModel {

        @Override
        public int getRowCount() {
            return alip.size();
        }

        @Override
        public int getColumnCount() {
            return 1;
        }

        @Override
        public String getColumnName(int i) {
            String c[] = {"IP Address"};
            return c[i];
        }

        @Override
        public Object getValueAt(int i, int j) {
            return alip.get(i);
        }

    }

    class mytablemodel2 extends AbstractTableModel {

        @Override
        public int getRowCount() {
            return al2.size();
        }

        @Override
        public int getColumnCount() {
            return 2;
        }

        @Override
        public String getColumnName(int i) {
            String s[] = {"IP Address", "PC Name"};
            return s[i];
        }

        @Override
        public Object getValueAt(int i, int j) {
            PCinfo pi = al2.get(i);
            if (j == 0) {
                return pi.ip;
            }
            if (j == 1) {
                return pi.pcname;
            }

            return "anything";
        }

    }

    class Detect implements Runnable {

        @Override
        public void run() {
                String s=JOptionPane.showInputDialog("Enter Range");
           credentials.range=s;
    
            int c = 1;
   /*        for (int i = 1; i <= 17; i++) {
                Thread t[] = new Thread[15];
                for (int j = 0; j < 15; j++) {
                    job obj = new job(c);
                    t[j] = new Thread(obj);
                    t[j].start();
                    c++;
              }
               for (int j = 0; j < 15; j++) {
                    try {
                        t[j].join();
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
             System.out.println(i + " " + "slot completed");
            }
*/
   
           for(int i =200; i<250; i++){
               job obj = new job(i);
               Thread t = new Thread(obj);
                t.start();
            }
       }
    }

    class job implements Runnable {

        int ip;

        job(int ip) {
            this.ip = ip;
        }

        @Override
        public void run() {
            try {
                Process p = Runtime.getRuntime().exec("ping " + credentials.range + ip);
                DataInputStream dis = new DataInputStream(p.getInputStream());
                int count = 0;
                while (true) {
                    String s = dis.readLine();
                    if (s == null) {
                        break;
                    } else if (s.contains("TTL")) {
                        count++;
                    }
                }
                if (count == 4) {
                    System.out.println(credentials.range + ip + " " + "System Connected");
                    alip.add(credentials.range + ip);
                    tm.fireTableDataChanged();
                    lb.setText(alip.size() + " " + "System(s) Connected");
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }

    class Client implements Runnable 
    {

        String ip;

        Client(String ip) {
            this.ip = ip;
        }

        @Override
        public void run() {
            try {
                Socket sock = new Socket(ip, 5000);

                DataInputStream dis = new DataInputStream(sock.getInputStream());
                DataOutputStream dos = new DataOutputStream(sock.getOutputStream());

                dos.writeBytes("hello server\r\n");

                String pcname = sock.getInetAddress().getHostName();
                al2.add(new PCinfo(ip, pcname));
                tm2.fireTableDataChanged();
                String s = dis.readLine();
                System.out.println(s);

            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

    }
}
        
