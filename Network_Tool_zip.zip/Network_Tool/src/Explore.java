
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class Explore extends javax.swing.JFrame {
    
    String request = "";
    
    ArrayList<PCinfo> al2;

    public Explore(ArrayList<PCinfo> al2) {
        initComponents();
        
        int width = Toolkit.getDefaultToolkit().getScreenSize().width;
        int height = Toolkit.getDefaultToolkit().getScreenSize().height;
        
        this.al2 = al2;
        setSize(width, height);
        lb.setText(al2.size() + "System(s) Connected");
        
        SinglePanel sp[] = new SinglePanel[al2.size()];
        int x = 30, y = 50;
        for (int i = 0; i < al2.size(); i++) {
            sp[i] = new SinglePanel();
            sp[i].setBounds(x, y, 270, 270);
            sp[i].lb2.setText(al2.get(i).ip);
            sp[i].lb3.setText(al2.get(i).pcname);
            mainpanel.add(sp[i]);
            final String IP = al2.get(i).ip;
            
            sp[i].addMouseListener(new MouseAdapter() 
            {
                
                public void mouseClicked(MouseEvent e) 
                {
                    if (e.getClickCount() == 2) {
                        request = "Send configuration";
                        Client obj = new Client(IP);
                        Thread t = new Thread(obj);
                        t.start();
                        
                    }
                    else
                    {
                       
                        if(e.getButton()==3)
                        {
                            PopupMenu pop=new PopupMenu();
                            
                            MenuItem mi1=new MenuItem("Shut Down");
                            MenuItem mi2=new MenuItem("Restart");
                            MenuItem mi3=new MenuItem("Logg Off");
                            MenuItem mi4=new MenuItem("View Screen");
                            pop.add(mi1);
                            pop.add(mi2);
                            pop.add(mi3);
                            pop.add(mi4);
                            
                            add(pop);
                            pop.show(Explore.this,e.getXOnScreen(),e.getYOnScreen());
                            
                             mi1.addActionListener(new ActionListener()
                            {
                              public void actionPerformed(ActionEvent e)
                                {
                                       request="Shut down";
                                        new Thread(new Client(IP)).start();       
                                }
                             });
                             
                              mi2.addActionListener(new ActionListener()
                            {
                              public void actionPerformed(ActionEvent e)
                                {
                                       request="Restart";
                                        new Thread(new Client(IP)).start();       
                                }
                             });
                              
                               mi3.addActionListener(new ActionListener()
                            {
                              public void actionPerformed(ActionEvent e)
                                {
                                       request="Logg Off";
                                        new Thread(new Client(IP)).start();       
                                }
                             });
                               
                                mi4.addActionListener(new ActionListener()
                            {
                              public void actionPerformed(ActionEvent e)
                                {
                                       request="View Screen";
                                        new Thread(new Client(IP)).start();       
                                }
                             });
                        }
                        
                    }
                    
                }
                
            });
            
            
           
            
            if (x < 800) {
                x = x + 270;
            } else {
                x = 30;
                y = y + 70;
            }
            
        }
        
    }
    
    private Explore() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainpanel = new javax.swing.JPanel();
        lb = new javax.swing.JLabel();
        sidepanel = new javax.swing.JPanel();
        lb1 = new javax.swing.JLabel();
        lb2 = new javax.swing.JLabel();
        lbpcname = new javax.swing.JLabel();
        lb3 = new javax.swing.JLabel();
        lb4 = new javax.swing.JLabel();
        lb5 = new javax.swing.JLabel();
        lb6 = new javax.swing.JLabel();
        lbip = new javax.swing.JLabel();
        lbos = new javax.swing.JLabel();
        lbpro = new javax.swing.JLabel();
        lbram = new javax.swing.JLabel();
        bt = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        mainpanel.setBackground(new java.awt.Color(255, 204, 255));
        mainpanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 4));
        mainpanel.setLayout(null);

        lb.setText("Connected Systems");
        mainpanel.add(lb);
        lb.setBounds(30, 20, 140, 40);

        getContentPane().add(mainpanel);
        mainpanel.setBounds(0, 0, 1060, 680);

        sidepanel.setBackground(new java.awt.Color(255, 204, 204));
        sidepanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));
        sidepanel.setLayout(null);

        lb1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pics/download.jpg"))); // NOI18N
        sidepanel.add(lb1);
        lb1.setBounds(30, 20, 170, 150);

        lb2.setText("IP Address :");
        sidepanel.add(lb2);
        lb2.setBounds(20, 180, 90, 30);
        sidepanel.add(lbpcname);
        lbpcname.setBounds(90, 230, 120, 20);

        lb3.setText("PC Name :");
        sidepanel.add(lb3);
        lb3.setBounds(20, 230, 80, 30);

        lb4.setText("OS :");
        sidepanel.add(lb4);
        lb4.setBounds(20, 270, 80, 30);

        lb5.setText("No. of Processors :");
        sidepanel.add(lb5);
        lb5.setBounds(20, 310, 100, 40);

        lb6.setText("RAM :");
        sidepanel.add(lb6);
        lb6.setBounds(20, 360, 70, 30);
        sidepanel.add(lbip);
        lbip.setBounds(90, 180, 120, 30);

        lbos.setText("jLabel2");
        sidepanel.add(lbos);
        lbos.setBounds(80, 274, 110, 30);
        sidepanel.add(lbpro);
        lbpro.setBounds(120, 320, 100, 20);
        sidepanel.add(lbram);
        lbram.setBounds(90, 370, 100, 20);

        bt.setText("Export to Excel");
        sidepanel.add(bt);
        bt.setBounds(40, 430, 150, 50);

        getContentPane().add(sidepanel);
        sidepanel.setBounds(1070, 0, 230, 680);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bt1ActionPerformed(java.awt.event.ActionEvent evt) {                                    
        
        try {

            File f1 = new File(System.getProperty("user.home") + "\\Controller Files");
            if (!f1.exists()) {
                f1.mkdir();
            }
            File f = new File(System.getProperty("user.home") + "\\Controller Files\\" + lbpcname.getText() + ".xls");
            HSSFWorkbook workbook = new HSSFWorkbook();
            HSSFSheet sheet = workbook.createSheet("FirstSheet");

            HSSFRow row0 = sheet.createRow((short) 0);
            row0.createCell(0).setCellValue("PC Name : ");
            row0.createCell(1).setCellValue(lbpcname.getText());

            HSSFRow row1 = sheet.createRow((short) 1);
            row1.createCell(0).setCellValue("OS Name : ");
            row1.createCell(1).setCellValue(lbos.getText());

            HSSFRow row2 = sheet.createRow((short) 2);
            row2.createCell(0).setCellValue("No. of Processors : ");
            row2.createCell(1).setCellValue(lbpro.getText());

            HSSFRow row3 = sheet.createRow((short) 3);
            row3.createCell(0).setCellValue("RAM");
            row3.createCell(1).setCellValue(lbram.getText());
            
            FileOutputStream fileOut = new FileOutputStream(f);
            workbook.write(fileOut);
            fileOut.close();
            //System.out.println("Your excel file has been generated!");
            int r = JOptionPane.showConfirmDialog(rootPane, "Excel File has been generated!!!!!!!\n Do you want to open? ");
            if (r == JOptionPane.YES_OPTION) {
                Desktop.getDesktop().open(f);
            }
        }
            catch(Exception ex)
                    {
                    ex.printStackTrace();
                    }
    }
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Explore.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Explore.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Explore.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Explore.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Explore().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bt;
    private javax.swing.JLabel lb;
    private javax.swing.JLabel lb1;
    private javax.swing.JLabel lb2;
    private javax.swing.JLabel lb3;
    private javax.swing.JLabel lb4;
    private javax.swing.JLabel lb5;
    private javax.swing.JLabel lb6;
    private javax.swing.JLabel lbip;
    private javax.swing.JLabel lbos;
    private javax.swing.JLabel lbpcname;
    private javax.swing.JLabel lbpro;
    private javax.swing.JLabel lbram;
    private javax.swing.JPanel mainpanel;
    private javax.swing.JPanel sidepanel;
    // End of variables declaration//GEN-END:variables

    class Client implements Runnable {

        String ip;
        
        Client(String ip) {
            this.ip = ip;
        }

        @Override
        public void run() {
            try {
                Socket sock = new Socket(ip, 5000);
                
                DataInputStream dis = new DataInputStream(sock.getInputStream());
                DataOutputStream dos = new DataOutputStream(sock.getOutputStream());
                
                if (request.equalsIgnoreCase("Send Configuration")) {
                    dos.writeBytes("Send Configuration\r\n");
                    
                    String ip = dis.readLine();
                    String name = dis.readLine();
                    String os = dis.readLine();
                    String pro = dis.readLine();
                    String ram = dis.readLine();
                    
                    lbip.setText(ip);
                    lbpcname.setText(name);
                    lbos.setText(os);
                    lbpro.setText(pro);
                    lbram.setText(Math.round(Long.parseLong(ram)/(1024.0*1024*1024))+"GB");
                }
                else if(request.equalsIgnoreCase("Shut Down"))
                {
                    dos.writeBytes("Shut Down\r\n");
                }
                else if(request.equalsIgnoreCase("Restart"))
                {
                    dos.writeBytes("Restart\r\n");
                }
                else if(request.equalsIgnoreCase("Logg Off"))
                {
                    dos.writeBytes("Logg Off\r\n");
                }
                else if(request.equalsIgnoreCase("View Screen"))
                {
                    dos.writeBytes("Send your screen Size\r\n");
                    
                    int sw=dis.readInt();
                    int sh=dis.readInt();
                    
                     int mw = Toolkit.getDefaultToolkit().getScreenSize().width;
                     int mh = Toolkit.getDefaultToolkit().getScreenSize().height;
                     
                     FullScreenView obj=new FullScreenView(ip);
                     if(sw<mw && sh<mh)
                     {
                         obj.setSize(sw,mh);
                         obj.jScrollPane1.setSize(sw,sh);
                         obj.lb.setSize(sw,sh);
                         obj.setVisible(true);
                     }
                     else
                             {
                               obj.setSize(mw,mh);
                               obj.jScrollPane1.setSize(mw,mh);
                               obj.lb.setSize(sw,sh);
                               obj.setVisible(true);  
                             }
                }
                
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        
    }
    
}
