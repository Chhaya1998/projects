import java.io.*;

class PCinfo
{

    String ip,pcname;
    boolean cb;
    PCinfo(String i,String p)
    {
       ip=i;
       pcname=p;
    }
    
     PCinfo(String i,String p,boolean cb)
    {
        ip=i;
        pcname=p;
        this.cb=cb;
        
    }
   
   
}