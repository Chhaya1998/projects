
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;


public class ComparisonFrame extends javax.swing.JFrame 
{
    ArrayList<PCinfo> al2;
    ArrayList<PCinfo> alSelected=new ArrayList<>();
    
    mytablemodel tm;
    public ComparisonFrame(ArrayList<PCinfo> al2) 
    {
        initComponents();
        setSize(500, 500);
        this.al2=al2;
        
        tm=new mytablemodel();                
        jtb.setModel(tm);        
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lb = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtb = new javax.swing.JTable();
        bt1 = new javax.swing.JButton();
        bt2 = new javax.swing.JButton();
        bt3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        lb.setText("Select Systems to Compare");
        getContentPane().add(lb);
        lb.setBounds(35, 20, 220, 14);

        jtb.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Title 1", "Title 2"
            }
        ));
        jScrollPane1.setViewportView(jtb);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(30, 60, 230, 190);

        bt1.setText("Select All");
        bt1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt1ActionPerformed(evt);
            }
        });
        getContentPane().add(bt1);
        bt1.setBounds(40, 290, 100, 30);

        bt2.setText("Deselect All");
        bt2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt2ActionPerformed(evt);
            }
        });
        getContentPane().add(bt2);
        bt2.setBounds(160, 290, 100, 30);

        bt3.setText("Compare");
        bt3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt3ActionPerformed(evt);
            }
        });
        getContentPane().add(bt3);
        bt3.setBounds(290, 290, 110, 30);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bt1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt1ActionPerformed
        for (int i = 0; i < al2.size(); i++)
            {
                al2.get(i).cb=true;
                tm.fireTableDataChanged();
            }
    }//GEN-LAST:event_bt1ActionPerformed

    private void bt2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt2ActionPerformed
        for (int i = 0; i < al2.size(); i++)
            {
                al2.get(i).cb=false;
                tm.fireTableDataChanged();
            }
    }//GEN-LAST:event_bt2ActionPerformed

    private void bt3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt3ActionPerformed
        
        alSelected.clear();
        for(int i=0;i<al2.size();i++)
        {
            if(al2.get(i).cb==true)
            {
                alSelected.add(al2.get(i));
            }
        }
        
        if(alSelected.size()<2 || alSelected.size()>5)
        {
            JOptionPane.showMessageDialog(this,"Select the Optimum range");
        }
        else
        {
             int r=JOptionPane.showConfirmDialog(this, "You have selected"+alSelected.size()+"devices.\nDo you wish to continue!!");
        
        
            if(r==JOptionPane.OK_OPTION)
             {
                   ComparisonFrame2 obj=new ComparisonFrame2( alSelected);
                   obj.setVisible(true);
              }
        }
           
        
    }//GEN-LAST:event_bt3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ComparisonFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ComparisonFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ComparisonFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ComparisonFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
//                new ComparisonFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bt1;
    private javax.swing.JButton bt2;
    private javax.swing.JButton bt3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jtb;
    private javax.swing.JLabel lb;
    // End of variables declaration//GEN-END:variables

  class mytablemodel extends AbstractTableModel 
  {

        @Override
        public int getRowCount() 
        {
            return al2.size();
        }

        @Override
        public int getColumnCount() 
        {
            return 3;
        }

        @Override
        public String getColumnName(int i) 
        {
            String c[] = {"Select","IP Address","PC Name"};
            return c[i];
        }

        @Override
        public Object getValueAt(int i, int j) 
        {
            PCinfo pi= al2.get(i);
            if(j==0)
            {
               return al2.get(i).cb;
            }
            
            else if(j==1)
            {
                return pi.ip;
            }
            else
            {
                 return pi.pcname;
            }
        

        }
        
         public Class getColumnClass(int c)
        {
            return getValueAt(0, c).getClass();
        }
        public void setValueAt(Object value, int i, int j)
        {            
            al2.get(i).cb = (Boolean) (value);
            fireTableCellUpdated(i, j);
        }

        @Override
        public boolean isCellEditable(int i, int j)
        {
            if (j == 0)
            {
                return true;
            } else
            {
                return false;
            }
        }
    }
}

